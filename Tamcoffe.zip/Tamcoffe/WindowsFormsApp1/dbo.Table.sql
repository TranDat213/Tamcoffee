﻿CREATE TABLE [dbo].[Table]
(
	[TenTaiKhoan] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [MatKhau] VARCHAR(50) NULL, 
    [Email] VARCHAR(50) NULL
)
